from pencil_art import pencil_art

input_image = r"D:\Usmonov Shohruxmiroz's Projects\PYTHON\Python\projects\img.png"
output_image = "sketch.jpg"
    
pencil_art(input_image, output_image)
