from pencil_art import core

input_image = r"D:\Usmonov Shohruxmiroz's Projects\PYTHON\Python\projects\img.png"
output_image = "sketch.jpg"
    
core(input_image, output_image)
